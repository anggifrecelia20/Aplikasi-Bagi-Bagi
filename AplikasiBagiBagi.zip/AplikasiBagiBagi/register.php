<?php
session_start();

if(isset($_SESSION['usr_id'])) {
	header("Location: index.php");
}

include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['signup'])) {
	$name = mysqli_real_escape_string($con, $_POST['name']);
	$nim = mysqli_real_escape_string($con, $_POST['nim']);
	$universitas = mysqli_real_escape_string($con, $_POST['universitas']);
	$program_studi = mysqli_real_escape_string($con, $_POST['program_studi']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	$cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
	$poin= mysqli_real_escape_string($con, $_POST['poin']);
	
	//name can contain only alpha characters and space
	if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
		$error = true;
		$name_error = "Nama mengandung alphabet";
	}

	if (!preg_match("/^[a-zA-Z0-9 ]+$/",$nim)) {
		$error = true;
		$nim_error = "NIM mengandung alphabet dan nomor ";
	}

	if (!preg_match("/^[a-zA-Z ]+$/",$universitas)) {
		$error = true;
		$universitas_error = "Universitas mengandung alphabet";
	}

	if (!preg_match("/^[a-zA-Z ]+$/",$program_studi)) {
		$error = true;
		$program_studi_error = "Program Studi mengandung alphabet";
	}

	if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$error = true;
		$email_error = "Tolong berikan email yang valid";
	}
	if(strlen($password) < 6) {
		$error = true;
		$password_error = "Password must be minimum of 6 characters";
	}
	if($password != $cpassword) {
		$error = true;
		$cpassword_error = "Password and Confirm Password doesn't match";
	}
	if (!preg_match("/^[10 ]+$/",$poin)) {
		$error = true;
		$poin_error = "Maksimal poin adalah 10";
	}

	if (!$error) {
		if(mysqli_query($con, "INSERT INTO users(name,nim,universitas,program_studi,email,poin,password) VALUES('" . $name . "', '" . $nim . "', '" . $universitas . "', '" . $program_studi . "',  '" . $email . "', '" . $poin . "',  '" . md5($password) . "')")) {
			$successmsg = "Successfully Registered! <a href='login.php'>Click here to Login</a>";
		} else {
			$errormsg = "Error in registering...Please try again later!";
		}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" >
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
    body {
		font-family: 'Varela Round', sans-serif;
	}
	.modal-login {		
		color: #636363;
		width: 350px;
	}
	.modal-login .modal-content {
		padding: 20px;
		border-radius: 5px;
		border: none;
	}
	.modal-login .modal-header {
		border-bottom: none;   
        position: relative;
        justify-content: center;
	}
	.modal-login h4 {
		text-align: center;
		font-size: 26px;
		margin: 30px 0 -15px;
	}
	.modal-login .form-control:focus {
		border-color: #70c5c0;
	}
	.modal-login .form-control, .modal-login .btn {
		min-height: 40px;
		border-radius: 3px; 
	}
	.modal-login .close {
        position: absolute;
		top: -5px;
		right: -5px;
	}	
	.modal-login .modal-footer {
		background: #ecf0f1;
		border-color: #dee4e7;
		text-align: center;
        justify-content: center;
		margin: 0 -20px -20px;
		border-radius: 5px;
		font-size: 13px;
	}
	.modal-login .modal-footer a {
		color: #999;
	}		
	.modal-login .avatar {
		position: absolute;
		margin: 0 auto;
		left: 0;
		right: 0;
		top: -70px;
		width: 95px;
		height: 95px;
		border-radius: 50%;
		z-index: 9;
		background: #60c7c1;
		padding: 15px;
		box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
	}
	.modal-login .avatar img {
		width: 100%;
	}
	.modal-login.modal-dialog {
		margin-top: 80px;
	}
    .modal-login .btn {
        color: #fff;
        border-radius: 4px;
		background: #60c7c1;
		text-decoration: none;
		transition: all 0.4s;
        line-height: normal;
        border: none;
    }
	.modal-login .btn:hover, .modal-login .btn:focus {
		background: #45aba6;
		outline: none;
	}
	.trigger-btn {
		display: inline-block;
		margin: 100px auto;
	}
</style>
</head>
<body>


<div class="modal-dialog modal-login">
	<div class="modal-content">
		<div class="modal-header">
			<div class="avatar">
				<img src="images/download (1).png" alt="Avatar">
				</div>				
				<h4 class="modal-title">Member Register</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
			<div class="form-group">
						<label for="name">Nama</label>
						<input type="text" class="form-control" name="name" placeholder="nama lengkap anda" required value="<?php if($error) echo $name; ?>">		
						<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
			</div>
			<div class="form-group">
						<label for="name">NIM</label>
						<input type="text" class="form-control" name="nim" placeholder="nim anda" required value="<?php if($error) echo $nim; ?>" class="form-control">		
						<span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
			</div>
			<div class="form-group">
						<label for="name">Universitas</label>
						<input list="universitas" name="universitas" class="form-control" >
						<datalist id="universitas">
						<option value="Institut Teknologi Del">
						<option value="Institut Teknologi Bandung">
						<option value="Institut Teknologi Sumatera">
						<option value="Institut Pertanian Bogor">
						<option value="Universitas Airlangga">
						<option value="Universitas Andalas">
						<option value="Universitas Brawijaya">
						<option value="Universitas Gajah Mada">
						<option value="Universitas Hassanudin">
						<option value="Universitas Indonesia">
						<option value="Universitas Negeri Medan">
						<option value="Universitas Negeri Jakarta">
						<option value="Universitas Sumatera Utara">
						<option value="Universitas Udayana">
						<option value="Lainnya">
						</datalist>
			</div>
			<div class="form-group">
						<label for="name">Prodi</label>
						<input list="program_studi" name="program_studi" class="form-control" >
						<datalist id="program_studi">
						<option value="Sistem Informasi">
						<option value="Teknik Informatika">
						<option value="Teknik Komputer">
						<option value="Manajemen Rekayasa">
						<option value="Teknik Bioproses">
						</datalist>
						
			</div>		
			<div class="form-group">
						<label for="name">Email</label>
						<input type="text" class="form-control" name="email" placeholder="Email" required value="<?php if($error) echo $email; ?>" class="form-control"> 		
						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
			</div>
			<div class="form-group">
						<label for="name">Password</label>
						<input type="password" class="form-control" name="password" placeholder="Password" required class="form-control"> 		
						<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
			</div>	

			<div class="form-group">
						<label for="name">Confirm Password</label>
						<input type="password" class="form-control" name="cpassword" placeholder="Confirm Password" required class="form-control"> 		
						<span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
			</div>	

			<div class="form-group">
			<label for="name">Poin Awal Anda: </label>
			<input type="poin" class="form-control" name="poin" readonly value="10" placeholder="poin awal" required class="form-control">
			<span class="text-danger"><?php if (isset($poin_error)) echo $poin_error; ?></span>
			</div>

			<div class="form-group">
			<button type="submit" name="signup" value="Sign Up" class="btn btn-primary btn-lg btn-block signup-btn" onclick="window.Location='login.php';">Sign Up</button>
			</div>
			<span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
			<span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
		</div>
		
		</div>
	
		</div>
		<script src="js/jquery-1.10.2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		</body>
		</html>



