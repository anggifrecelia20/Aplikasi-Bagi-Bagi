<?php
session_start();
include_once 'dbconnect.php';

$mei =$_SESSION['usr_id'];



$query= "SELECT * FROM users where id=". $mei;
// $result_sets = $con->query($query);  

                $result_sets = $con->query($query); 


while($data = mysqli_fetch_array($result_sets)){
                $point = $data['poin'];
                // var_dump($point);die();

}


?>
                    
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
 


    <title>BagiBagi</title>
    
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
    <link href="css/nivo-lightbox.css" rel="stylesheet" />
    <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
    <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

    <!-- boxed bg -->
    <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
    <!-- template skin -->
    <link id="t-colors" href="color/default.css" rel="stylesheet">
    
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


<div id="wrapper">
    
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="top-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                    <big> <b>  
                    <?php
                    echo " <span>" . date('l, Y-m-d') . "<br>";
                    ?>
                    </b> </big>
                    </div>
                    <div class="col-sm-6 col-md-6">
                    <p class="bold text-right">Selamat Berbagi!</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container navigation">
        
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
              <ul class="nav navbar-nav">

              <?php if (isset($_SESSION['usr_id']))

               { 


                ?>
              
                <li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
                <li ><a href="index.php">Home</a></li>
                <li class="active"><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li><a href="akun.php">Data Diri</a></li>
                <li><a href="logout.php">Logout</a></li>
                <?php } 
                else { ?>
                <li ><a href="index.php">Home</a></li>
                
                <li class="active"><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
                 <ul class="dropdown-menu">
                    <li><a href="login.php"> Sudah Punya Akun </a></li>
                    <li><a href="register.php"> Belum Punya Akun</a></li>
                    <?php } ?>
                  </ul>
                </li>
              </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    
    
    

    






<!-- KOMPETISI -->

<!-- Section: team -->
    <section id="facilities" class="home-section bg-gray paddingbot-60">
        <div class="container marginbot-50">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="wow lightSpeedIn" data-wow-delay="0.1s">
                    <div class="section-heading text-center">
                    <h2 class="h-bold">Kompetisi</h2>
                    <div class="divider-short"></div>
                    <br> <br>
                    <a align="centre" href="bagi_kompetisi.php" class="btn btn-skin btn-lg">Tambah Informasi Kompetisi </a> 
                    <a align="centre" href="index.php" class="btn btn-skin btn-lg">Kembali </a>    
                    </div>
                    <div class="col-md-4">
                    <div class="wow lightSpeedIn" data-wow-delay="0.1s">
                    <div class="cta-btn">
                    
                    </div>
                    </div>
                    
                </div>
            </div>
        </div>
        

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
          <!--       
            <div id="filters-container" class="cbp-l-filters-alignLeft">
                <div data-filter="*" class="cbp-filter-item-active cbp-filter-item">All (<div class="cbp-filter-counter"></div>)</div>
                <div data-filter=".sosial" class="cbp-filter-item">Sosial (<div class="cbp-filter-counter"></div>)</div>
                <div data-filter=".design" class="cbp-filter-item">Desain (<div class="cbp-filter-counter"></div>)</div>
                <div data-filter=".programming " class="cbp-filter-item">Programming (<div class="cbp-filter-counter"></div>)</div>
            </div> -->
        
            <div id="grid-container" class="cbp-l-grid-team">
                <ul>

                    
                    <?php
                        // include"dbconnect.php";
                        $query= "SELECT * FROM kompetisi";
                        $sql = mysqli_query($con,$query);
                        while($data = mysqli_fetch_array($sql)){
                            $id_foto = $data['id'];
                            $foto = $data['foto'];

                                                    ?>




                    <li class="cbp-item programming">

                        <!--<a href="mei.php" class="cbp-caption cbp-singlePage">-->

                            <?php 
                            if($point >=3){

                            ?>

                        <a href="mei.php?id_kompetisi= <?php echo urlencode($data['id']);?>" class="cbp-caption cbp-singlePage">
                            <?php
                        }
                            ?>
                        
                        
                            <div class="cbp-caption-defaultWrap">
                        
                                <img src="img/<?php echo $foto; ?>" width="100%">
                        
                            </div>
                            <div class="cbp-caption-activeWrap">
                                <div class="cbp-l-caption-alignCenter">
                                    <div class="cbp-l-caption-body">
                                        <div class="cbp-l-caption-text">LIHAT KOMPETISI</div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="" class="cbp-singlePage cbp-l-grid-team-name"><?php echo $data['judul'];?></a>
                        <div class="cbp-l-grid-team-position"><?php echo $data['deskripsi'];?></div>
                    </li>
                    <?php } ?>





                </ul>


            </div>
            </div>
            </div>
        </div>

    </section>
    <!-- /Section: team -->




        
    
   

   <footer>
    
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="wow fadeInLeft" data-wow-delay="0.1s">
                    <div class="text-left">
                    <p>&copy; - HORE TEAM.</p>
                    </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="wow fadeInRight" data-wow-delay="0.1s">
                    <div class="text-right">
                        <div class="credits">
                            <a>Aplikasi Berbagi Informasi Kompetisi dan Beasiswa Bagi Mahasiswa</a>
                        </div>
                    </div>
                    </div>
                </div>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>     
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.scrollTo.js"></script>
    <script src="js/jquery.appear.js"></script>
    <script src="js/stellar.js"></script>
    <script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/nivo-lightbox.min.js"></script>
    <script src="js/custom.js"></script>
    
</body>

</html>
