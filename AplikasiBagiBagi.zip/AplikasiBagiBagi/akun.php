<?php
	include_once('dbconnect.php');
	include_once('load.php');
	include_once('functions.php');
	open_page('Bagi Bagi');

	include_once('head.php');



	if (($_SESSION['usr_id']) == NULL)
		
		echo '
			<script language="javascript">
				alert("Kami tidak dapat mengenali akun anda. Anda harus login terlebih dahulu.");
				document.location="index.php";
			</script>
		';
	
?>

<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
 


    <title>BagiBagi</title>
  
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
    <link href="css/nivo-lightbox.css" rel="stylesheet" />
    <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
    <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
$(document).ready(function() {
    var panels = $('.user-infos');
    var panelsButton = $('.dropdown-user');
    panels.hide();

    //Click dropdown
    panelsButton.click(function() {
        //get data-for attribute
        var dataFor = $(this).attr('data-for');
        var idFor = $(dataFor);

        //current button
        var currentButton = $(this);
        idFor.slideToggle(400, function() {
            //Completed slidetoggle
            if(idFor.is(':visible'))
            {
                currentButton.html('<i class="glyphicon glyphicon-chevron-up text-muted"></i>');
            }
            else
            {
                currentButton.html('<i class="glyphicon glyphicon-chevron-down text-muted"></i>');
            }
        })
    });


    $('[data-toggle="tooltip"]').tooltip();

    $('button').click(function(e) {
        e.preventDefault();
        alert("This is a demo.\n :-)");
    });
});

</script>	
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

  <!-- boxed bg -->
  <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">
  <style type="text/css">

.user-row {
    margin-bottom: 14px;
}

.user-row:last-child {
    margin-bottom: 0;
}

.dropdown-user {
    margin: 13px 0;
    padding: 5px;
    height: 100%;
}

.dropdown-user:hover {
    cursor: pointer;
}

.table-user-information > tbody > tr {
    border-top: 1px solid rgb(0, 0, 0);
}

.table-user-information > tbody > tr:first-child {
    border-top: 2;
}


.table-user-information > tbody > tr > td {
    border-top: 0;
}
.toppad
{margin-top:20px;
}

</style>
    
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<div id="wrapper">
    
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="top-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                    <big> <b>  
                    <?php
                    echo " <span>" . date('l, Y-m-d') . "<br>";
                    ?>
                    </b> </big>
                    </div>
                    <div class="col-sm-6 col-md-6">
                    <p class="bold text-right">Selamat Berbagi!</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container navigation">
        
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

             <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
              <ul class="nav navbar-nav">
              <?php if (isset($_SESSION['usr_id'])) { ?>
                <li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
                <li ><a href="index.php">Home</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="active"><a href="akun.php">Data Diri</a></li>
                <?php if ($_SESSION['usr_id']== 19 ){?>
                    <li ><a href="berikoin.php">Admin</a></li>
                <?php } ?>
                <li><a href="logout.php">Logout</a></li>
                <?php } else { ?>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="tentang.php">Tentang Bagi-Bagi</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
                 <ul class="dropdown-menu">
                    <li><a href="login.php"> Sudah Punya Akun </a></li>
                    <li><a href="register.php"> Belum Punya Akun</a></li>
                    <?php } ?>
          </ul>
        </li>
        </ul>
            </div>
            
        </div>
       
    </nav>

		<?php

						
			$id=$_SESSION['usr_id'];

			$result_set = profile($id);

			$sql = "Select * from users where id=".$id;
			$result_set = $con->query($sql);

			while($row = $result_set->fetch_assoc()){ 
				
				if($row['gender']==0){
					$row['gender']='Perempuan';
				}
				else{
					$row['gender']='Laki-laki';
				}

				
			?>
			
		</div>

<br> <br> <br>
<div class="container">
      <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
      <div class="panel panel-info">
            <div class="panel-heading">
            	<h3 class="panel-title"> <?php echo $row['name']?> </h3>
            
            	<div class="panel-body">
              	<div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img src="images/download (1).png" alt="Avatar" class="img-circle img-responsive"> </div>
              <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Email:</td>
                        <td><?php echo $row['email']?></td>
                      </tr>
                      <tr>
                        <td>Universitas:</td>
                        <td><?php echo $row['universitas']?></td>
                      </tr>
                      <tr>
                        <td>Program Studi:</td>
                        <td><?php echo $row['program_studi']?></td>
                      </tr>
                        <tr>
                        <td>Jenis Kelamin:</td>
                        <td><?php echo $row['gender']?></td>
                      </tr>
                        <tr>
                        <td>Total Poin:</td>
                        <td><?php echo $row['poin']?></td>
                      </tr>                         
                    </tbody>
                  </table>
                  <a href="isikoin.php" class="btn btn-primary">Isi Ulang Poin</a>
                  </div>
              </div>
            </div>
            <div class="panel-footer">
            	<span class="pull-right">
                            <a href="process.php?form_profil='.$id.'" data-original-title="Update Data Diri" data-toggle="tooltip" type="button" button id="trueAuto" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a href="process.php?upd_pass='.$id.'" data-original-title="Update Password" data-toggle="tooltip" type="button" button id="trueAuto" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                        </span>
                </div>
            </div>
        </div>
    </div>
</div>



      
      <?php  }?>
    </div>




