<?php
session_start();
include_once 'dbconnect.php';

$mei =$_SESSION['usr_id'];



$query= "SELECT * FROM users where id=". $mei;
// $result_sets = $con->query($query);  

 $result_sets = $con->query($query); 


while($data = mysqli_fetch_array($result_sets)){
$point = $data['poin'];

}


?>
                    
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    
 


    <title>BagiBagi</title>
    
    <!-- css -->
    <link href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
    <link href="css/nivo-lightbox.css" rel="stylesheet" />
    <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
    <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

    <!-- boxed bg -->
    <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
    <!-- template skin -->
    <link id="t-colors" href="color/default.css" rel="stylesheet">
    <style type="text/css">
    body{
        color: #999;
        background: #e2e2e2;
        font-family: 'Roboto', sans-serif;
    }
    .form-control{
        min-height: 41px;
        box-shadow: none;
        border-color: #e1e1e1;
    }
    .form-control:focus{
        border-color: #00cb82;
    }   
    .form-control, .btn{        
        border-radius: 3px;
    }
    .form-header{
        margin: -30px -30px 20px;
        padding: 30px 30px 10px;
        text-align: center;
        background: #00cccc;
        border-bottom: 1px solid #eee;
        color: #fff;
    }
    .form-header h2{
        font-size: 34px;
        font-weight: bold;
        margin: 0 0 10px;
        font-family: 'Times New Roman', sans-serif;
        color: #fff;
    }
    .form-header p{
        margin: 20px 0 15px;
        font-size: 17px;
        line-height: normal;
        font-family: 'Courgette', sans-serif;
    }
    .signup-form{
        width: 390px;
        margin: 0 auto; 
        padding: 30px 0;    
    }
    .signup-form form{
        color: #999;
        border-radius: 3px;
        margin-bottom: 15px;
        background: #f0f0f0;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .signup-form .form-group{
        margin-bottom: 20px;
    }       
    .signup-form label{
        font-weight: normal;
        font-size: 13px;
    }
    .signup-form input[type="checkbox"]{
        margin-top: 2px;
    }
    .signup-form .btn{        
        font-size: 16px;
        font-weight: bold;
        background: #00cccc;
        border: none;
        min-width: 200px;
    }
    .signup-form .btn:hover, .signup-form .btn:focus{
        background: #00b073 !important;
        outline: none;
    }
    .signup-form a{
        color: #00cccc;     
    }
    .signup-form a:hover{
        text-decoration: underline;
    }
</style>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<div id="wrapper">
    
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="top-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                    <big> <b>  
                    <?php
                    echo " <span>" . date('l, Y-m-d') . "<br>";
                    ?>
                    </b> </big>
                    </div>
                    <div class="col-sm-6 col-md-6">
                    <p class="bold text-right">Selamat Berbagi!</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container navigation">
        
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
             <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
              <ul class="nav navbar-nav">
              <?php if (isset($_SESSION['usr_id'])) { ?>
                <li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
                <li ><a href="index.php">Home</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="active"><a href="akun.php">Data Diri</a></li>
                <?php if ($_SESSION['usr_id']== 19 ){?>
                    <li ><a href="berikoin.php">Admin</a></li>
                <?php } ?>
                <li><a href="logout.php">Logout</a></li>
                <?php } else { ?>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="tentang.php">Tentang Bagi-Bagi</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
                 <ul class="dropdown-menu">
                    <li><a href="login.php"> Sudah Punya Akun </a></li>
                    <li><a href="register.php"> Belum Punya Akun</a></li>
                    <?php } ?>
                  </ul>
                </li>
              </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
		
        <br> <br> <br> <br> <br> <br> <br> 

<div class="signup-form">

<form method="post" action="proses_pesan.php" name='pesanpoin' title="form isi ulang poin">

<div class="form-header">
        <h2>Form Isi Koin</h2>
        <p>Silahkan isi jumlah koin yang ingin anda beli!</p>
 </div>		
		
 <div class="form-group">
         <label>Banyak Poin</label>
         <input type="text" class="form-control" name="banyakoin" size="137" onFocus="startCalc();" >
 </div>

 <div class="form-group">
        <label>Harga Poin</label>
        <input type="text" class="form-control" value="3000" size="137" name="nilai2" onFocus="startCalc();">
 </div>
		
 <div class="form-group">
        <label>Total Harga</label>
        <input type="text" size="137" class="form-control" name="total_harga" onchange="tryNumberFormat(this.form.thirdBox);">
 </div>		 
					



<div class="form-group">
  <button type="submit" id="true" name="submit"  class="btn btn-primary btn-block btn-lg">Isi Poin</button>
</div>

<a href="akun.php"><button type="button" id="false" class="btn btn-primary btn-block btn-lg">Kembali ke Data Diri</button></a>
	
    </div> 
   
				


	
</div>

<script>
function startCalc(){
interval = setInterval("calc()",1);}
function calc(){
y = document.pesanpoin.banyakoin.value;
z = document.pesanpoin.nilai2.value;

document.pesanpoin.total_harga.value = ( y * z );}
function stopCalc(){
clearInterval(interval);}
</script>


  
</form>
	