<?php
session_start();
include_once 'dbconnect.php';

$mei =$_SESSION['usr_id'];



$query= "SELECT * FROM users where id=". $mei;
// $result_sets = $con->query($query);  

                $result_sets = $con->query($query); 


while($data = mysqli_fetch_array($result_sets)){
                $point = $data['poin'];

}


?>
                    
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
 


    <title>BagiBagi</title>
    
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
    <link href="css/nivo-lightbox.css" rel="stylesheet" />
    <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
    <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

    <!-- boxed bg -->
    <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
    <!-- template skin -->
    <link id="t-colors" href="color/default.css" rel="stylesheet">
    
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


<div id="wrapper">
    
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="top-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                    <big> <b>  
                    <?php
                    echo " <span>" . date('l, Y-m-d') . "<br>";
                    ?>
                    </b> </big>
                    </div>
                    <div class="col-sm-6 col-md-6">
                    <p class="bold text-right">Selamat Berbagi!</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container navigation">
        
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
              <ul class="nav navbar-nav">

              <?php if (isset($_SESSION['usr_id']))

               { 


                ?>
              
                <li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
                <li><a href="index.php">Home</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li><a href="akun.php">Data Diri</a></li>
                <li class="active"><a href="berikoin.php">Admin</a></li>
                <li><a href="logout.php">Logout</a></li>
                <?php } 
                else { ?>
                <li><a href="index.php">Home</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
                 <ul class="dropdown-menu">
                    <li><a href="login.php"> Sudah Punya Akun </a></li>
                    <li><a href="register.php"> Belum Punya Akun</a></li>
                    <?php } ?>
                  </ul>
                </li>
              </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    

<br><br>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
    body {
        color: #566787;
        background: #f5f5f5;
        font-family: 'Roboto', sans-serif;
    }
    .table-wrapper {
        width: 850px;
        background: #fff;
        padding: 20px 30px 5px;
        margin: 30px auto;
        box-shadow: 0 0 1px 0 rgba(0,0,0,.25);
    }
    .table-title .btn-group {
        float: right;
    }
    .table-title .btn {
        min-width: 50px;
        border-radius: 2px;
        border: none;
        padding: 6px 12px;
        font-size: 95%;
        outline: none !important;
        height: 30px;
    }
    .table-title {
        border-bottom: 1px solid #e9e9e9;
        padding-bottom: 15px;
        margin-bottom: 5px;
        background: rgb(0, 50, 74);
        margin: -20px -31px 10px;
        padding: 15px 30px;
        color: #fff;
    }
    .table-title h2 {
        margin: 2px 0 0;
        font-size: 24px;
    }
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
        padding: 12px 15px;
        vertical-align: middle;
    }
    table.table tr th:first-child {
        width: 40px;
    }
    table.table tr th:last-child {
        width: 100px;
    }
    table.table-striped tbody tr:nth-of-type(odd) {
        background-color: #fcfcfc;
    }
    table.table-striped.table-hover tbody tr:hover {
        background: #f5f5f5;
    }
    table.table td a {
        color: #2196f3;
    }
    table.table td .btn.manage {
        padding: 2px 10px;
        background: #37BC9B;
        color: #fff;
        border-radius: 2px;
    }
    table.table td .btn.manage:hover {
        background: #2e9c81;        
    }

.modal-confirm {        
        color: #636363;
        width: 325px;
    }
    .modal-confirm .modal-content {
        padding: 20px;
        border-radius: 5px;
        border: none;
    }
    .modal-confirm .modal-header {
        border-bottom: none;   
        position: relative;
    }
    .modal-confirm h4 {
        text-align: center;
        font-size: 26px;
        margin: 30px 0 -15px;
    }
    .modal-confirm .form-control, .modal-confirm .btn {
        min-height: 40px;
        border-radius: 3px; 
    }
    .modal-confirm .close {
        position: absolute;
        top: -5px;
        right: -5px;
    }   
    .modal-confirm .modal-footer {
        border: none;
        text-align: center;
        border-radius: 5px;
        font-size: 13px;
    }   
    .modal-confirm .icon-box {
        color: #fff;        
        position: absolute;
        margin: 0 auto;
        left: 0;
        right: 0;
        top: -70px;
        width: 95px;
        height: 95px;
        border-radius: 50%;
        z-index: 9;
        background: #33cccc;
        padding: 15px;
        text-align: center;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
    }
    .modal-confirm .icon-box i {
        font-size: 58px;
        position: relative;
        top: 3px;
    }
    .modal-confirm.modal-dialog {
        margin-top: 80px;
    }
    .modal-confirm .btn {
        color: #fff;
        border-radius: 4px;
        background: #33cccc;
        text-decoration: none;
        transition: all 0.4s;
        line-height: normal;
        border: none;
    }
    .modal-confirm .btn:hover, .modal-confirm .btn:focus {
        background: #009999;
        outline: none;
    }
    .trigger-btn {
        display: inline-block;
        margin: 100px auto;
    }
    
</style>
<script type="text/javascript">
$(document).ready(function(){
    $(".btn-group .btn").click(function(){
        var inputValue = $(this).find("input").val();
        if(inputValue != 'all'){
            var target = $('table tr[data-status="' + inputValue + '"]');
            $("table tbody tr").not(target).hide();
            target.fadeIn();
        } else {
            $("table tbody tr").fadeIn();
        }
    });
    // Changing the class of status label to support Bootstrap 4
    var bs = $.fn.tooltip.Constructor.VERSION;
    var str = bs.split(".");
    if(str[0] == 4){
        $(".label").each(function(){
            var classStr = $(this).attr("class");
            var newClassStr = classStr.replace(/label/g, "badge");
            $(this).removeAttr("class").addClass(newClassStr);
        });
    }
});
</script>
</head>
<body>
    <br> <br> <br> <br>
    <div class="table-wrapper">
        <div class="table-title">
            <div class="row">
                <div class="col-sm-6"><h2>Tabel Pembelian Koin</b></h2></div>
            </div>
        </div>
     <table class="table table-striped table-hover">
     <thead>
            <tr>
            <th>#</th>
            <th>Banyak Poin</th>
            <th>Total Harga</th>
            </tr>
            </thead>
            <?php
            $query="SELECT * FROM pesan";
            $sql=mysqli_query($con, $query);
            while($data=mysqli_fetch_array($sql))
            {
            ?>
            <tr data-status="active">
            <td><?php echo $data['id_pesan'] ?></td>
            <td><span class="label label-warning"><?php echo $data['banyakoin'] ?></span></td>
            <td> <span class="label label-success"><?php echo $data['total_harga'] ?></span></td>
            </tr>
        <?php
        }
        ?>
        </tbody>
        </table>
        </div>      
    <div class="table-wrapper">
        <div class="table-title">
            <div class="row">
                <div class="col-sm-6"><h2>Tabel Bukti Pembayaran Koin </b></h2></div>
            </div>
        </div>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama File</th>
                    <th>Tipe File</th>
                    <th>File Size(KB)</th>
                    <th>Lihat File</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql="SELECT * FROM tbl_uploads";
                $result_set=mysqli_query($con, $sql);
                while($row=mysqli_fetch_array($result_set))
                {
                ?>
                <tr data-status="active">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['file'] ?></td>
                    <td><?php echo $row['type'] ?></td>
                    <td><?php echo $row['size'] ?></td>
                    <td><a href="uploads/<?php echo $row['file'] ?>" class="btn btn-sm manage">view file</a></td>
                    <div class="text-center">
                    <!-- Button HTML (to Trigger Modal) -->
                    <td><a href="#myModal" data-toggle="modal" class="btn btn-sm manage">Kirim Koin</a></td>
                    <div id="myModal" class="modal fade">
                    <div class="modal-dialog modal-confirm">
                    <div class="modal-content">
                    <div class="modal-header">
                    <div class="icon-box">
                    <i class="material-icons">&#xE876;</i>
                    </div>              
                    <h4 class="modal-title">Selamat!</h4>   
                     </div>
                    <div class="modal-body">
                <p class="text-center">Koin telah dikirimkan.</p>
            </div>
            <div class="modal-footer">
                <button  class="btn btn-success btn-block" data-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>     
    </tr>
                 <?php
                 }
                 ?>
            </tbody>
        </table>
      
    </div>  
  
</body>
</html>