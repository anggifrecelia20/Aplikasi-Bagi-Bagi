<?php
session_start();

include_once('dbconnect.php'); 
include_once('load.php');

open_page('Bagi Bagi');

	include_once('head.php');

if(isset($_GET['view'])){

		$id=$_GET['view'];	
		$result_set = userView($id);	
		while($row = $result_set->fetch_assoc()){ 

		if($row['gender']==0){
			$row['gender']='female';
		}
		else{
			$row['gender']='male';
		}


		echo '

		<div class="container">
		<div class="col-md-12">
			<h2>View Data Customer</h2>
		</div>
		
		<div class="col-md-6">

			<table border="1.5" class="table table-hover table-bordered table-striped">

				<tr style="background-color: skyblue">
					<td>NAMA</td>
					<td>'.$row['name'].'</td>
				</tr>
				<tr>
					<td>Email</td>
					<td>'.$row['nim'].'</td>
				</tr>
				<tr>
					<td>Universitas</td>
					<td>'.$row['universitas'].'</td>
				</tr>
				<tr>
					<td>Program Studi</td>
					<td>'.$row['program_studi'].'</td>
				</tr>
				<tr>
					<td>Email</td>
					<td>'.$row['email'].'</td>
				</tr>
				<tr>
					<td>GENDER</td>
					<td>'.$row['gender'].'</td>
				</tr>
					
			</table>
		
		</div><br>

	</div>

		';
		} 
	}

// === MENAMPILKAN FORM UPDATE DATA USER ===
else if(isset($_GET['update'])){

		$id=$_GET['update'];	
		$result_set = userView($id);
		while($row = $result_set->fetch_assoc()){ 

		echo '

		<div class="container">
			<div class="col-md-6">
				<div class="panel panel-primary">
					
					<div class="panel-heading" style="height:65-px; text-align: left">
						<label style="font-size: 1.5em">Update Data</label>
					</div>

					<div class="panel-body">
						<form method="post" action="user_manajemen.php?update_process='.$row['id'].'">
							<input type="text" class="form-control" name="name" value="'.$row['name'].'" required><br>
							<input type="text" class="form-control" name="nim" value="'.$row['nim'].'" required><br>
							<input type="text" class="form-control" name="universitas" value="'.$row['universitas'].'" required><br>
							<input type="text" class="form-control" name="program_studi" value="'.$row['program_studi'].'" required><br>
							<input type="text" class="form-control" name="email" value="'.$row['email'].'" required><br>
								<h4>
							<input type="radio" value="'.$row['gender'].'" name="gender">Female &emsp;&emsp; 
							<input type="radio" value="'.$row['gender'].'" name="gender">Male
								</h4><br>
							<div style="text-align: right;">
								<a href="akun.php"><button type="button" id="false">Cancel</button></a>
								<button type="submit" name="submit" id="true" >Submit</button>
							</div>
						</form> 
					</div>

				</div>
			</div><br>
		</div>

		';
		} 
	}



// === MELAKUKAN PEMROSESAN TERHADAP AKSI UPDATE DATA USER ===
	else if(isset($_GET['update_process']))	{
		$id=$_GET['update_process'];

		$name = $_POST['name'];
		$nim = $_POST['nim'];
		$universitas = md5($_POST['universitas']);
		$program_studi= $_POST['program_studi'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];

		if($gender==0){
			$gender='female';
		}
		else{
			$gender='male';
		}
		
		$result_set = userUpdateProcess($name, $nim, $universitas, $program_studi, $email, $gender);
		
		if($result_set){
			echo '
				<script language="javascript">
					alert("Sukses mengubah data akun.");
					document.location="index.php";
				</script>
			';
		}
		
	}



// MELAKUKAN PEMROSESAN DELETE DATA USER
	else if(isset($_GET['delete']))	{
		
		$account_id=$_GET['delete'];
		$result_set = userDelete($id);
		
		if($result_set){
			echo '
				<script language="javascript">
					alert("Sukses menghapus akun.");
					document.location="index.php";
				</script>
			';
		}

		
	}




// PROCESS UNTUK PROFIL USER
// === MENAMPILKAN FORM UPDATE DATA USER

	if(isset($_GET['form_profil'])){

		$id=$_GET['form_profil'];	
				
		$result_set = profil($id);
		
		while($row = $result_set->fetch_assoc()){ 
		echo '

		<div class="container" id="container">
			
			<div class="col-md-6 col-md-offset-3">
		
				<div class="panel panel-primary">
					<div class="panel-heading" style="height:80px; text-align: center">
						<h2>Update Data Diri</h2>
					</div>

					<div class="panel-body">

					<form method="post" action="proses.php?update_profil='.$row['id'].'" enctype="multipart/form-data">
						Nama Lengkap : 
						<input type="text" class="form-control" name="name" value="'.$row['name'].'" required><br>
						Nim : 
						<input type="text" class="form-control" name="nim" value="'.$row['nim'].'" required><br>
						Universitas: 
						<input type="text" class="form-control" name="universitas" value="'.$row['universitas'].'" required><br>
						Program Studi : 
						<input type="text" class="form-control" name="program_studi" value="'.$row['program_studi'].'" required><br>
						Email : 
						<input type="email" class="form-control" name="email" value="'.$row['email'].'" required><br>
						<div style="font-size : 1.2em">
						Jenis kelamin :
						<input type="radio" value="'.$row['gender'].'" name="gender">Perempuan &emsp;&emsp; 
						<input type="radio" value="'.$row['gender'].'" name="gender">Laki-laki
						</div><br>
						<div style="text-align:right">
							<a href="akun.php"><button type="button" id="false">Cancel</button></a>
						
							<button type="submit" name="submit" id="true">Submit
							</button>
						</div>

						</form> 
					</div>
				</div>
				
			</div><br>

		</div>

			';

		
		}
	}



// === MELAKUKAN PROSES UPDATE PROFIL DATA USER ===
	else if(isset($_GET['update_profil']))	{
		$id=$_GET['update_profil'];

		$name = $_POST['name'];
		$nim = $_POST['nim'];
		$universitas= $_POST['universitas'];
		$program_studi = $_POST['program_studi'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];


		$update = profilUpdateProcess($name, $nim, $universitas, $program_studi, $email, $gender);

		if ($update){
			echo '
				<script language="javascript">
					alert("Berhasil mengubah data profil.");
					document.location="akun.php";
				</script>
			';
		}
		else{
			echo '
				<script language="javascript">
					alert("Gagal melakukan perubahan.");
					document.location="akun.php";
				</script>
			';
		}
		
	}

	else if(isset($_GET['upd_pass'])){

		$id=$_GET['upd_pass'];	
				
		$result_set = profil($id);
		
		while($row = $result_set->fetch_assoc()){ 
		echo '

		<div class="container" id="container">
			
			<div class="col-md-6 col-md-offset-3">
		
				<div class="panel panel-primary">
					<div class="panel-heading" style="height:80px; text-align: center">
						<h2>Update Password</h2>
					</div>

					<div class="panel-body">

					<form method="post" action="proses.php?upd_pass_process='.$row['id'].'" enctype="multipart/form-data">
						
						Password Sebelumnya:
						<input type="password" class="form-control" name="last_pass" required><br>
						Password Baru:
						<input type="password" class="form-control" name="new_pass" required><br>
						Konfirmasi Password Baru:
						<input type="password" class="form-control" name="new_pass2" required><br>
						
						<div style="text-align:right">
							<a href="akun.php"><button type="button" id="false">Cancel</button></a>
						
							<button type="submit" name="submit" id="true">Submit
							</button>
						</div>

						</form> 
					</div>
				</div>
				
			</div><br>

		</div>

			';

		
		}
	}

	else if(isset($_GET['upd_pass_process']))	{
		$id=$_GET['upd_pass_process'];
		$last_pass = md5($_POST['last_pass']);
		$new_pass = md5($_POST['new_pass']);
		$new_pass2 = md5($_POST['new_pass2']);
		
		$result_set = check_pass($id);

		while($row = $result_set->fetch_assoc()){
			
			$pass=$row['password'];
		}
		if($pass==$last_pass){
			if($new_pass==$new_pass2){
				$upd_password = upd_password($new_pass, $id);
				if ($upd_password){
					echo '
						<script language="javascript">
							alert("Berhasil mengubah password.");
							document.location="akun.php";
						</script>
					';
				}
				else{
					echo '
						<script language="javascript">
							alert("Gagal melakukan perubahan.");
							document.location="akun.php";
						</script>
					';
				}
			}
			else{
				echo '
						<script language="javascript">
							alert("Gagal melakukan perubahan. Kedua password tidak sama.");
							document.location="akun.php";
						</script>
					';
			}
		}
		else{
			echo '
						<script language="javascript">
							alert("Gagal melakukan perubahan. Password lama anda tidak sama dengan sebelumnya.");
							document.location="akun.php";
						</script>
					';
		}

		
		
	}

	else if(isset($_GET['upd_photo'])){

		$id=$_GET['upd_photo'];	
				
		$result_set = profile($id);
		
		while($row = $result_set->fetch_assoc()){ 
		echo '

		<div class="container" id="container">
			
			<div class="col-md-6 col-md-offset-3">
		
				<div class="panel panel-primary">
					<div class="panel-heading" style="height:80px; text-align: center">
						<h2>Update Photo Profil</h2>
					</div>

					<div class="panel-body">

					<form method="post" action="proses.php?upd_photo_process='.$row['id'].'" enctype="multipart/form-data">
						
						Foto Profil
						<input type="file" name="fileToUpload" id="fileToUpload">
						<div style="text-align:right">
							<a href="profil.php"><button type="button" id="false">Cancel</button></a>
						
							<button type="submit" name="submit" id="true">Submit
							</button>
						</div>

						</form> 
					</div>
				</div>
				
			</div><br>

		</div>

			';

		
		}
	}

	else if(isset($_GET['upd_photo_process']))	{
		$id=$_GET['upd_photo_process'];
		
		$target_dir = "upload/";
		$target_file = $target_dir .basename($_FILES["fileToUpload"]["name"]);
		$file_type = pathinfo($target_file,PATHINFO_EXTENSION);

		if (!move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			echo '
				<script language="javascript">
					alert("Gagal memindai gambar.");
					document.location="akun.php";
				</script>
			';
		}
		else{
			$upd_photo = upd_photo($target_file, $id);

			if ($upd_photo){
				echo '
					<script language="javascript">
						alert("Berhasil mengubah data profil.");
						document.location="akun.php";
					</script>
				';
			}
			else{
				echo '
					<script language="javascript">
						alert("Gagal mengubah photo profil.");
						document.location="akun.php";
					</script>
				';
			}
		}
		
		
		
	}