<?php
include('dbconnect.php');

//perhatikan!
if(isset($_POST['teditbeasiswa'])){
	$id	= $_POST['id'];
	$judul	= $_POST['judul'];
	$deskripsi	= $_POST['deskripsi'];

	
	
	$sql	= 'update beasiswa set judul="'.$judul.'", deskripsi="'.$deskripsi.'" where id="'.$id.'"';
	$query	= mysqli_query($con,$sql);
	
	if($query){
		header('location: beasiswa.php');
	}
	else{
		echo 'Gagal';
	}
}


?>
	
