
<?php

	// session_start();
// include_once('dbconnect.php');
//var_dump($_SESSION['usr_id']);die();
// if (isset($_SESSION['usr_id'])){

session_start();

include_once 'dbconnect.php';

// var_dump($_GET['id_kompetisi']);die();

    $query= "SELECT * FROM beasiswa where id= ".$_GET['id_beasiswa'];
    $sql = mysqli_query($con,$query);
    while($data = mysqli_fetch_array($sql)){
			    $id_foto = $data['id'];
			    $foto = $data['foto'];
			    $id_deskripsi = $data['id'];
			    $deskripsi= $data['deskripsi'];
			    $id_judul = $data['id'];
			    $judul = $data['judul'];
      


//var_dump($result_set);die();
//mysqli_query($con, "UPDATE users SET poin=poin-3  WHERE id =".$id);// update quantity
//mysqli_close($con);


}

$sql = "UPDATE users SET poin=poin-3  WHERE id= ".$_SESSION['usr_id'];
$result_set = $con->query($sql);


// var_dump('test');die();
?>

<div class="cbp-l-member-img">
	 <img src="img/<?php echo $foto; ?>" width="100%" height="50%">
</div>
<div class="cbp-l-member-info  <?php echo $judul; ?>">
	<div> </div>
	<div class="cbp-l-member-desc <?php echo $deskripsi; ?>>

Dalam rangka Dies Natalis Fakultas Psikologi UGM yang ke-50 (Lustrum X). Panitia Lustrum X Psikologi UGM mengadakan lomba desain logo ulang tahun fakultas Psikologi UGM yang ke-50. Logo akan digunakan sebagai lambang acara Dies Natalis yang akan berlangsung selama 1 tahun acara.

poster

Tema Dies Natalis Fakultas Psikologi UGM yang ke-50 : "Menjadi Insan Indonesia yang Tangguh dan Bahagia"

Kriteria penilaian dari logo adalah :
– Kesesuaian dengan Tema
– Filosofi Logo (dilampirkan bersama logo)
– Orisinalitas

Peserta :
– Civitas Akademika Psikologi UGM
– Alumni Psikologi UGM
– Mahasiswa UGM
– Pelajar SMA / sederajat

Hadiah:
– Juara 1 : Rp 3.000.000,-
– Juara 2 : Rp 2.000.000,-
– Juara 3 : Rp 1.500.000,-
		<br>
		<a href="http://psikologi.ugm.ac.id/lomba-desain-logo-lustrum-x-psikologi-ugm/">Lihat Selengkapnya</a>
	</div>
</div>
