<?php
	session_start();
	
	//KONEKSI DATABASE
	global $database;
	$database = mysqli_connect('127.0.0.1', 'root', '', 'pa1'); 

	if (!$database) {
		die("database connect problem");
	}

	$db_use = mysqli_select_db($database,"pa1") or die("select db problem");
	
	function execQ($query){
		global $database;
		
		$set = mysqli_query($database, $query);

		return $set;	
	}



	//OTHER FUNCTION

	
	function destroy_session($_key){
		unset($_SESSION[$_key]);
	}

	function login($username, $password){
		$query = "SELECT * FROM account WHERE username='$username' OR password='$password'";
		return execQ($query);
	}

	function check_pass($account_id){
		$query = "SELECT * FROM account WHERE account_id='$account_id'";
		return execQ($query);
	}

	function add($name, $username, $password, $email, $hp, $gender, $role_id){
		$query = "INSERT INTO account (name, username, password, email, hp, gender, role_id) VALUES('$name', '$username', '$password', '$email', '$hp', '$gender', '$role_id')";
		return execQ($query);
	}

	function signup($name, $username, $password, $email, $hp, $gender, $role){
		$query = "INSERT INTO account (name, username, password, email, hp, gender, role_id) VALUES('$name', '$username', '$password', '$email', '$hp', '$gender', 3)";
		return execQ($query);
	}

	function signupCheck($username, $email){
		$query = "SELECT * FROM account WHERE username='$username' OR email='$email'";
		return execQ($query);
	}
	
	function hitungRow(){
		$query="SELECT max(account_id) as maksimal FROM account";
		$queryH = execQ($query);
			while($hasil=mysqli_fetch_array($queryH))
			{
			$nilai=$hasil['maksimal'];
			}
		return $nilai;
	}	
	function gallery(){
		$query = 'SELECT * FROM gallery';
		return execQ($query);
	}

	function galleryData(){
		$query = 'SELECT * FROM gallery ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function galleryDelete($gallery_id){
		$query = "DELETE FROM gallery WHERE gallery_id='$gallery_id'";
		return execQ($query);
	}

	function galleryAdd($category, $description, $target_file, $account_id){
		$query = "INSERT INTO gallery (cat_id, description, picture, account_id) VALUES('$category', '$description', '$target_file', '$account_id')";
		return execQ($query);
	}

	function gallery1(){
		$query = 'SELECT * FROM gallery WHERE cat_id=1 ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function gallery2(){
		$query = 'SELECT * FROM gallery WHERE cat_id=2 ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function gallery3(){
		$query = 'SELECT * FROM gallery WHERE cat_id=3 ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function gallery4(){
		$query = 'SELECT * FROM gallery WHERE cat_id=4 ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function gallery5(){
		$query = 'SELECT * FROM gallery WHERE cat_id=5 ORDER BY gallery_id DESC';
		return execQ($query);
	}

	function gallery6(){
		$query = 'SELECT * FROM gallery WHERE cat_id=6 ORDER BY gallery_id DESC';
		return execQ($query);
	}


	function banana(){
		$query = 'SELECT * FROM banana';	
		return execQ($query);
	}

	function rolee(){
		$query = 'SELECT * FROM role';	
		return execQ($query);
	}


	function bananaAll(){
		$query = 'SELECT * FROM banana ORDER BY banana_id DESC';	
		return execQ($query);
	}

	function bananaDetail($banana_id){
		$query = 'SELECT * FROM banana WHERE banana_id='.$banana_id;	
		return execQ($query);
	}

	function terima($booking_id){
		$query = "UPDATE booking SET status_id=2 WHERE booking_id='$booking_id'";
		return execQ($query);
	}

	function tolak($booking_id){
		$query = "UPDATE booking SET status_id=3 WHERE booking_id='$booking_id'";
		return execQ($query);
	}

	function batal($booking_id){
		$query = "UPDATE booking SET status_id=4 WHERE booking_id='$booking_id'";
		return execQ($query);
	}

	function bookingDataUser($account_id){
		$query = "SELECT * FROM booking WHERE account_id='$account_id' ORDER BY booking_id DESC";	
		return execQ($query);
	}

	function bookingData(){
		$query = "SELECT * FROM booking ORDER BY booking_id DESC";	
		return execQ($query);
	}

	function bookingDetail($booking_id){
		$query = "SELECT * FROM booking WHERE booking_id='$booking_id'";	
		return execQ($query);
	}

	function  bookingNew($account_id, $banana_id, $dateNow, $tanggal, $waktu, $lama){
		$query = "INSERT INTO booking (account_id, banana_id, tgl_pesan, tanggal, waktu, lama) VALUES('$account_id', '$banana_id', '$dateNow', '$tanggal', '$waktu', '$lama')";		
		return execQ($query);
	}

	function waktu(){
		$query = 'SELECT * FROM waktu ';
		return execQ($query);
	}

	function bookingAccount($account_id){
		$query = "SELECT * FROM account WHERE account_id='$account_id'";	
		return execQ($query);
	}

	function bookingBanana($banana_id){
		$query = "SELECT * FROM banana WHERE banana_id='$banana_id'";		
		return execQ($query);
	}
	function bookingBananaStatus($status_id){
		$query = "SELECT * FROM status WHERE status_id='$status_id'";		
		return execQ($query);	
	}

	function userView($account_id){
		$query = 'SELECT * FROM account WHERE account_id='.$account_id;	
		return execQ($query);
	}

	function userUpdateProcess($name, $username, $password, $email, $hp, $gender, $account_id){
		$query = "UPDATE account SET name='$name', username='$username', password='$password', email='$email', hp='$hp', gender='$gender' WHERE account_id='$account_id'";
		return execQ($query);
	}

	function userDelete($account_id){
		$query = "DELETE FROM account WHERE account_id='$account_id'";
		return execQ($query);
	}

	function nani(){
		$query = 'SELECT * FROM account WHERE account_id=1';	
		return execQ($query);
	}

	function andre(){
		$query = 'SELECT * FROM account WHERE account_id=2';	
		return execQ($query);
	}

	function hokkop(){
		$query = 'SELECT * FROM account WHERE account_id=3';	
		return execQ($query);
	}

	

	function adminnData(){
		$query = 'SELECT * FROM account WHERE role_id=1 ';			
		return execQ($query);
	}
	
	function ownerrData(){
		$query = 'SELECT * FROM account WHERE role_id=2 ';			
		return execQ($query);
	}

	function customerrData(){
		$query = 'SELECT * FROM account WHERE role_id=3 ';			
		return execQ($query);
	}

	function alllData(){
		$query = 'SELECT * FROM account  ';			
		return execQ($query);
	}
	function AdminData(){
		$query = 'SELECT * FROM account WHERE role_id=1 ORDER BY account_id DESC';	
		return execQ($query);
	}
	function ownerData(){
		$query = 'SELECT * FROM account WHERE role_id=2 ORDER BY account_id DESC';	
		return execQ($query);
	}
	function custData(){
		$query = 'SELECT * FROM account WHERE role_id=3 ORDER BY account_id DESC';	
		return execQ($query);
	}

	function galleryUpdate($gallery_id){
		$query = "SELECT * FROM gallery WHERE gallery_id='$gallery_id'";		
		return execQ($query);
	}

	function galleryUpdateProcess($description, $category, $target_file, $gallery_id){
		$query = "UPDATE gallery SET description='$description', cat_id='$category', picture='$target_file' WHERE gallery_id='$gallery_id'";	
		return execQ($query);
	}

	function category(){
		$query = 'SELECT * FROM category ';	
		return execQ($query);
	}

	function testimony(){
		$query = "SELECT * FROM testimony ORDER BY testimony_id DESC";
		return execQ($query);
	}

	function testimonyAccount($account_id){
		$query = "SELECT * FROM account WHERE account_id='$account_id' ORDER BY account_id DESC";	
		return execQ($query);
	}

	function testimonyNew($account_id, $title, $comment){
		$query = "INSERT INTO testimony (account_id, title, comment) VALUES('$account_id', '$title', '$comment')";
		return execQ($query);
	}

	function userAccount($default_index, $default_batas){
		$query = "SELECT * FROM account ORDER BY account_id limit ".$default_index.", ".$default_batas;	
		return execQ($query);
	}

	function account(){
		$query = "SELECT * FROM account";	
		return execQ($query);
	}

	function berita(){
		$query = "SELECT * FROM berita ORDER BY berita_id DESC";
		return execQ($query);
	}

	function beritaDetail($berita_id){
		$query = "SELECT * FROM berita WHERE berita_id='$berita_id'";
		return execQ($query);
	}

	function beritaUpdateProcess($judul, $subjudul, $selengkapnya, $target_file, $berita_id){
		$query = "UPDATE berita SET judul='$judul', subjudul='$subjudul', selengkapnya='$selengkapnya', gambar='$target_file' WHERE berita_id='$berita_id'";
		return execQ($query);
	}

	function beritaAdd($judul, $subjudul, $selengkapnya, $gambar, $account_id){
		$query = "INSERT INTO berita (judul, subjudul, selengkapnya, gambar, account_id) VALUES('$judul', '$subjudul', '$selengkapnya', '$gambar', '$account_id')";
		return execQ($query);
	}

	function beritaDelete($berita_id){
		$query = "DELETE FROM berita WHERE berita_id='$berita_id'";
		return execQ($query);
	}

	function bananaAdd($type, $capacity, $price, $target_file, $account_id){
		$query = "INSERT INTO banana (type, capacity, price, picture, account_id) VALUES('$type', '$capacity', '$price', '$target_file', '$account_id')";
		return execQ($query);
	}

	function bananaUpd($type, $capacity, $price, $target_file, $banana_id){
		$query = "UPDATE banana SET type='$type', capacity='$capacity', price='$price', picture='$target_file' WHERE banana_id='$banana_id'";
		return execQ($query);
	}

	function bananaDelete($banana_id){
		$query = "DELETE FROM banana WHERE banana_id='$banana_id'";
		return execQ($query);
	}

	function catUserAll(){
		$query = "SELECT * FROM account";
		return execQ($query);
	}

	function addKateg($name){
		$query = "INSERT INTO category (cat_name) VALUES('$name')";
		return execQ($query);
	}
	
	function reqPesan(){
		$query = "SELECT * FROM booking WHERE status_id=1";
		return execQ($query);
	}

	function terimaPesan(){
		$query = "SELECT * FROM booking WHERE status_id=2";
		return execQ($query);
	}

	function tolakPesan(){
		$query = "SELECT * FROM booking WHERE status_id=3";
		return execQ($query);
	}

	function batalPesan(){
		$query = "SELECT * FROM booking WHERE status_id=4";
		return execQ($query);
	}

	function allPesan(){
		$query = "SELECT * FROM booking";
		return execQ($query);
	}

	function booking($account_id, $banana_id, $harga, $dateNow, $tanggal, $waktu, $lama){
		$query = "INSERT INTO banana (account_id, banana_id, price, tgl_pesan, $tanggal, $waktu, $lama) VALUES('$account_id', '$banana_id', '$harga', '$dateNow', '$tanggal', '$waktu', '$lama')";
		return execQ($query);
	}

	
	
?>
