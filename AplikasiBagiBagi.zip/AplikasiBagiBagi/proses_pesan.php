<?php
include_once 'dbconnect.php';

session_start();

if(isset($_SESSION['usr_id'])) {
	header("Location: tabel.php");
}


//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['submit'])) {
	$id_pemesan = mysqli_real_escape_string($con, $_SESSION['usr_id']);
	$banyakoin = mysqli_real_escape_string($con, $_POST['banyakoin']);
	$total_harga = mysqli_real_escape_string($con, $_POST['total_harga']);
	// $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
	// $poin= mysqli_real_escape_string($con, $_POST['poin']);
	
	//name can contain only alpha characters and space


	// if (!$error) {

		if(mysqli_query($con, "INSERT INTO pesan (id_pemesan,banyakoin,total_harga) VALUES('" . $id_pemesan . "',  '" . $banyakoin . "', '" . $total_harga . "')")) {
header('tabel.php');
			$successmsg = "Successfully Registered! <a href='login.php'>Click here to Login</a>";
		} 
		else {
			$errormsg = "Error in registering...Please try again later!";
		}
	
}
?>