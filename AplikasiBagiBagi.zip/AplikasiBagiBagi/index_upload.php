<?php
session_start();

include_once 'dbconnect.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
 


    <title>BagiBagi</title>
  
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
    <link href="css/nivo-lightbox.css" rel="stylesheet" />
    <link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
    <link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

  <!-- boxed bg -->
  <link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
  <!-- template skin -->
  <link id="t-colors" href="color/default.css" rel="stylesheet">
    
  
</head>
<body>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<div id="wrapper">
    
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
        <div class="top-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                    <big> <b>  
                    <?php
                    echo " <span>" . date('l, Y-m-d') . "<br>";
                    ?>
                    </b> </big>
                    </div>
                    <div class="col-sm-6 col-md-6">
                    <p class="bold text-right">Selamat Berbagi!</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container navigation">
        
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

             <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
              <ul class="nav navbar-nav">
              <?php if (isset($_SESSION['usr_id'])) { ?>
                <li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
                <li ><a href="index.php">Home</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="active"><a href="akun.php">Data Diri</a></li>
                <?php if ($_SESSION['usr_id']== 19 ){?>
                    <li ><a href="berikoin.php">Admin</a></li>
                <?php } ?>
                <li><a href="logout.php">Logout</a></li>
                <?php } else { ?>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="tentang.php">Tentang Bagi-Bagi</a></li>
                <li><a href="kompetisi.php">Kompetisi</a></li>
                <li><a href="beasiswa.php">Beasiswa</a></li>
                <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
                 <ul class="dropdown-menu">
                    <li><a href="login.php"> Sudah Punya Akun </a></li>
                    <li><a href="register.php"> Belum Punya Akun</a></li>
                    <?php } ?>
          </ul>
        </li>
        </ul>
            </div>
            
        </div>
       
    </nav>
    <br> <br> <br>    <br> <br> <br>   <br> 
    <section id="callaction" class="home-section paddingtop-40">	
           <div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="callaction bg-gray">
							<div class="row">
								<div class="col-md-8">
									<div class="wow fadeInUp" data-wow-delay="0.1s">
									<div class="cta-text">

									<h3>Upload Bukti Pembayaran Poin</h3>
									<h6> Mohon melakukan transfer ke : </h4>
									<h4> Unit Bank 		: Mandiri </h4>
									<h4> Nomor Rekening : 165-000-072-3453 </h4>
									<h4> Atas Nama 	    : Hore Team </h4> 
								</h4>
									
									</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="wow lightSpeedIn" data-wow-delay="0.1s">
										<form action="upload.php" method="post" enctype="multipart/form-data">
										<div class="cta-btn">
										<input type="file" name="file" class="btn btn-skin btn-lg"/>
										<br> 
										<button type ="submit" name="btn-upload" class="btn btn-skin btn-lg">Upload</button>

										<button type ="cancel" name="btn-cancel" class="btn btn-danger">
											<a href="tabel.php">Kembali </a>
										</button>

										</form>
										 <br /><br />
  									  <?php
						if(isset($_GET['success']))
						{
						?>
       				 <label>Bukti Pembayaran berhasil diupload  
						<button class="btn btn-skin btn-lg">
       				 	<a href="view.php">Klik disini untuk melihat gambar</a>
						</button>
       				 </label>

       				<?php
					}
					else if(isset($_GET['fail']))
					{
					?>
        			<label>Ups! Ada masalah pada proses upload file.</label>
       				 <?php
					}
					else
					{
					?>
        
       				 <?php
					}
					?>
									</div>



								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
	</section>	



<section id="boxes" class="home-section paddingtop-80">
	
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-3">
					<div class="wow fadeInUp" data-wow-delay="0.2s">
						<div class="box text-center">
							
							<i class="fa fa-file-image-o fa-3x circled bg-skin"></i>
							<h4 class="h-bold">Upload Bukti Transfer</h4>
							<p>
							Upload bukti transfer dan admin akan memeriksa bukti transfer yang telah dikirim.
							</p>
						</div>
					</div>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="wow fadeInUp" data-wow-delay="0.2s">
						<div class="box text-center">
							<i class="fa fa-check fa-3x circled bg-skin"></i>
							<h4 class="h-bold">Cek Bukti Transfer</h4>
							<p>
							Admin melakukan pemeriksaan, bukti transfer otomatis diperiksa pada hari yang sama setelah diupload.
							</p>
						</div>
					</div>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="wow fadeInUp" data-wow-delay="0.2s">
						<div class="box text-center">
							<i class="fa fa-share-alt fa-3x circled bg-skin"></i>
							<h4 class="h-bold">Pengiriman Poin</h4>
							<p>
							Setelah bukti transfer yang dilakukan benar, admin akan segera mengirimkan poin ke akun anda.
							</p>
						</div>
					</div>
				</div>
				<div class="col-sm-3 col-md-3">
					<div class="wow fadeInUp" data-wow-delay="0.2s">
						<div class="box text-center">
							<i class="fa fa-circle-thin fa-3x circled bg-skin"></i>
							<h4 class="h-bold">Poin ditambahkan</h4>
							<p>
							Poin anda akan bertambah dan anda sudah dapat untuk mengakses informasi kompetisi dan beasiswa.
							</p>
						</div>
					</div>
				</div>
	</section>
	<footer>
	
				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInLeft" data-wow-delay="0.1s">
					<div class="text-left">
					<p>&copy; - HORE TEAM.</p>
					</div>
					</div>
				</div>

				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInRight" data-wow-delay="0.1s">
					<div class="text-right">
						<div class="credits">
                            <a>Aplikasi Berbagi Informasi Kompetisi dan Beasiswa Bagi Mahasiswa</a>
                        </div>
					</div>
					</div>
				</div>

	
	
	


</body>
</html>