<?php
session_start();
include_once 'dbconnect.php';
// $_SESSION['is_logged_in']=1;

	// var_dump($_SESSION['usr_id']);die();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
 


    <title>BagiBagi</title>
	
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
	<link href="css/nivo-lightbox.css" rel="stylesheet" />
	<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">

	<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="color/default.css" rel="stylesheet">
    
  
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


<div id="wrapper">
	
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-6">
					<big> <b>  
					<?php
					echo " <span>" . date('l, Y-m-d') . "<br>";
					?>
					</b> </big>
					</div>
					<div class="col-sm-6 col-md-6">
					<p class="bold text-right">Selamat Berbagi!</p>
					</div>
				</div>
			</div>
		</div>

        <div class="container navigation">
		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			  <ul class="nav navbar-nav">
			  <?php if (isset($_SESSION['usr_id'])) { ?>
				<li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="kompetisi.php">Kompetisi</a></li>
				<li><a href="beasiswa.php">Beasiswa</a></li>
				<li><a href="akun.php">Data Diri</a></li>
				<?php if ($_SESSION['usr_id']== 19 ){?>
                    <li ><a href="berikoin.php">Admin</a></li>
                <?php } ?>
				<li><a href="logout.php">Logout</a></li>
				<?php } else { ?>
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="tentang.php">Tentang Bagi-Bagi</a></li>
				<li><a href="kompetisi.php">Kompetisi</a></li>
				<li><a href="beasiswa.php">Beasiswa</a></li>
				<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
				 <ul class="dropdown-menu">
					<li><a href="login.php"> Sudah Punya Akun </a></li>
					<li><a href="register.php"> Belum Punya Akun</a></li>
					<?php } ?>
				  </ul>
				</li>
			  </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
	<!-- Section: intro -->
    <section id="intro" class="intro">
		<div class="intro-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-6">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
					<h2 class="h-ultra">Informasi Beasiswa & Kompetisi</h2>
					</div>
					<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.1s">
					<h4 class="h-light">Beasiswa & Kompetisi Desember 2017</h4>
					</div>
						<div class="well well-trans">
						<div class="wow fadeInRight" data-wow-delay="0.1s">

						<ul class="lead-list">
							<li>
								<span class="fa fa-check fa-2x icon-success"></span> 
								<span class="list">
									<a href="http://bit.ly/indonesianext2017" > <strong>Beasiswa Sertifikasi Internasional</strong></a>
								</span>
							</li>


							<li>
								<span class="fa fa-check fa-2x icon-success"></span> 
								<span class="list">
									<a href="http://bit.ly/beasiswaVIU" > <strong>Study in USA: Beasiswa Virginia International University</strong></a>
								</span>
							</li>

							<li>
								<span class="fa fa-check fa-2x icon-success"></span> 
								<span class="list">
									<a href="www.gemuhimadiktika.epizy.com" > <strong>Lomba Esai Mahasiswa Nasional GEMU 2017 di Uniska</strong></a>
								</span>
							</li>

						</ul>
						<p class="text-right wow bounceIn" data-wow-delay="0.4s">
						<!-- <a href="#" class="btn btn-skin btn-lg">Informasi Lanjut <i class="fa fa-angle-right"></i></a> -->
						</p>
						</div>
						</div>


					</div>
					<div class="col-lg-6">
						<div class="wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">
						<img src="img/college-students.jpg" class="img-responsive" alt="" />
						</div>
					</div>					
				</div>		
			</div>
		</div>		
    </section>
	
	<!-- /Section: intro -->
	
	<footer>
	
				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInLeft" data-wow-delay="0.1s">
					<div class="text-left">
					<p>&copy; - HORE TEAM.</p>
					</div>
					</div>
				</div>

				<div class="col-sm-6 col-md-6 col-lg-6">
					<div class="wow fadeInRight" data-wow-delay="0.1s">
					<div class="text-right">
						<div class="credits">
                            <a>Aplikasi Berbagi Informasi Kompetisi dan Beasiswa Bagi Mahasiswa</a>
                        </div>
					</div>
					</div>
				</div>


	<!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
    <script src="js/custom.js"></script>
    
</body>

</html>
