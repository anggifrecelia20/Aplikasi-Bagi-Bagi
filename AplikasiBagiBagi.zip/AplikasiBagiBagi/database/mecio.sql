-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2018 at 10:57 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mecio`
--

-- --------------------------------------------------------

--
-- Table structure for table `beasiswa`
--

CREATE TABLE `beasiswa` (
  `id` int(100) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beasiswa`
--

INSERT INTO `beasiswa` (`id`, `judul`, `deskripsi`, `foto`) VALUES
(12, 'Beasiswa Universitas Pertamina Kuliah S1 Tahun 2018 â€“ 2019', 'Deadline: 26 Januari 2018 (Gelombang 1), 9 Maret 2017 (Gelombang 2), dan 13 April 2018 (Gelombang 3)', '11012018204231'),
(13, 'BukaBeasiswa 2018', 'Tunjangan Biaya Pendidikan + Tunjangan Hidup', '11012018204736');

-- --------------------------------------------------------

--
-- Table structure for table `kompetisi`
--

CREATE TABLE `kompetisi` (
  `id` int(100) NOT NULL,
  `judul` text NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kompetisi`
--

INSERT INTO `kompetisi` (`id`, `judul`, `deskripsi`, `foto`) VALUES
(46, 'MaGe 2018', 'Tanggal : 24 s.d 25 Februari 2018 (Puncak Acara) || Multimedia and Game', '11012018202506'),
(47, 'Kompetisi KPK', 'Lomba Cipta Media Pembelajaran Anti Korupsi', '11012018202643'),
(50, 'IYCF 2018', ' Deadline: 05 Februari 2018 ||Indonesia Youth Colaboration Forum 2018', '11012018203224'),
(51, 'Lomba Desain Poster', 'DEADLINE: 1 Maret 2018INFO SAYEMBARA DESAIN - Info Lomba 2018 | Lomba Desain Poster berikut ini diselenggarakan oleh HIMATEMIA FT UNILA, Lampung, pada bulan Maret 2018.', '11012018203404'),
(52, 'Kompetisi INCHALL 2018 di ITS Tingkat ASIA', 'Deadline : 2 Februari 2018', '12012018031718'),
(53, 'Kompetisi INCHALL 2018 di ITS Tingkat ASIA', 'INCHALL 2018 di ITS Tingkat ASIA', '18012018020144'),
(54, 'Kompetisi Programming IT Del', 'Deadline : 20 Februari 2018', '18012018023444');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(100) NOT NULL,
  `id_pemesan` int(100) NOT NULL,
  `banyakoin` int(100) NOT NULL,
  `total_harga` int(100) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `id_pemesan`, `banyakoin`, `total_harga`, `file`, `status`) VALUES
(1, 15, 0, 60000, NULL, NULL),
(2, 15, 20, 60000, NULL, NULL),
(3, 15, 20, 60000, NULL, NULL),
(4, 15, 90, 270000, NULL, NULL),
(5, 15, 40, 120000, NULL, NULL),
(6, 16, 1, 3000, NULL, NULL),
(7, 16, 1, 3000, NULL, NULL),
(8, 19, 1, 3000, NULL, NULL),
(9, 19, 111, 333000, NULL, NULL),
(10, 16, 1, 3000, NULL, NULL),
(11, 16, 1, 3000, NULL, NULL),
(12, 16, 1, 3000, NULL, NULL),
(13, 16, 10, 30000, NULL, NULL),
(14, 16, 10, 30000, NULL, NULL),
(15, 16, 10, 30000, NULL, NULL),
(16, 20, 125, 375000, NULL, NULL),
(17, 20, 125, 375000, NULL, NULL),
(18, 20, 100, 300000, NULL, NULL),
(19, 20, 100, 300000, NULL, NULL),
(20, 20, 100, 300000, NULL, NULL),
(21, 20, 126, 378000, NULL, NULL),
(22, 20, 100, 300000, NULL, NULL),
(23, 20, 150, 450000, NULL, NULL),
(24, 20, 100, 300000, NULL, NULL),
(25, 16, 1, 3000, NULL, NULL),
(26, 16, 1, 3000, NULL, NULL),
(27, 21, 3, 9000, NULL, NULL),
(28, 21, 3, 9000, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE `tbl_uploads` (
  `id` int(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`id`, `file`, `type`, `size`) VALUES
(1, 'Mei', '', 0),
(2, '93541-20170311_092727.jpg', 'image/jpeg', 1931),
(3, '5138-20170311_092727.jpg', 'image/jpeg', 1931),
(4, '60573-20170311_092727.jpg', 'image/jpeg', 1931),
(5, '8354-20170311_092727.jpg', 'image/jpeg', 1931),
(6, '2028-1479881578529.jpg', 'image/jpeg', 65),
(7, '81232-bagi5.png', 'image/png', 73),
(8, '79825-bagi5.png', 'image/png', 73),
(9, '93552-komp_4.jpg', 'image/jpeg', 172),
(10, '22713-capture.jpg', 'image/jpeg', 10),
(11, '72593-capture.jpg', 'image/jpeg', 10),
(12, '42573-download-(1).png', 'image/png', 4),
(13, '91461-download-(1).png', 'image/png', 4),
(14, '61746-201801223-excess-2018-lomba-desain-poster-universitas-lampung---infosayembara-s107.jpg', 'image/jpeg', 8),
(15, '56780-88422-win_20160917_153110.jpg', 'image/jpeg', 38),
(16, '69892-87211-win_20161018_112317.jpg', 'image/jpeg', 50),
(17, '40399-k4.png', 'image/png', 226),
(18, '73642-1.png', 'image/png', 27),
(19, '86492-bea3.jpg', 'image/jpeg', 18),
(20, '94481-new4.jpg', 'image/jpeg', 23),
(21, '34353-1.png', 'image/png', 27),
(22, '64408-2.png', 'image/png', 36),
(23, '3703-k2.jpg', 'image/jpeg', 122),
(24, '27022-k3.jpg', 'image/jpeg', 22);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `poin` int(2) NOT NULL,
  `nim` varchar(100) DEFAULT NULL,
  `universitas` varchar(100) DEFAULT NULL,
  `program_studi` varchar(100) DEFAULT NULL,
  `gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `poin`, `nim`, `universitas`, `program_studi`, `gender`) VALUES
(9, 'mei', 'mei@mail.com', '072a740d449903272a42b3e423dae733', 10, '', '', '', ''),
(15, 'meiket', 'meiket@gmail.com', '88e5cc4742524d6c357bad341f5901b6', 82, '', '', '', ''),
(16, 'anggi', 'anggi@mail.com', 'e0bf5f93b93a528bd5cdb05f621d7202', 112, '', '', '', ''),
(18, 'meiketaren', 'meiketaren@gmail.com', 'cd59d25e69dd42353a77c5717fbe8ba6', 7, NULL, NULL, NULL, ''),
(19, 'admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 228, NULL, NULL, NULL, ''),
(20, 'Christine Sibuea', 'christine@mail.com', '8e8cb8ce462a299ce23df576a8d6a6c9', 354, '12S15029', 'Universitas Brawijaya', 'Manajemen Rekayasa', ''),
(21, 'David ', 'david@mail.com', '55fc5b709962876903785fd64a6961e5', 10, '12S15065', 'Institut Teknologi Del', 'Sistem Informasi', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beasiswa`
--
ALTER TABLE `beasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kompetisi`
--
ALTER TABLE `kompetisi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `fk_1` (`id_pemesan`);

--
-- Indexes for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beasiswa`
--
ALTER TABLE `beasiswa`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `kompetisi`
--
ALTER TABLE `kompetisi`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `pesan`
--
ALTER TABLE `pesan`
  ADD CONSTRAINT `fk_1` FOREIGN KEY (`id_pemesan`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
