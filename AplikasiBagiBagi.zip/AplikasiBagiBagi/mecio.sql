-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2018 at 01:15 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mecio`
--

-- --------------------------------------------------------

--
-- Table structure for table `beasiswa`
--

CREATE TABLE `beasiswa` (
  `id` int(100) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beasiswa`
--

INSERT INTO `beasiswa` (`id`, `judul`, `deskripsi`, `foto`) VALUES
(12, 'Beasiswa Universitas Pertamina Kuliah S1 Tahun 2018 â€“ 2019', 'Deadline: 26 Januari 2018 (Gelombang 1), 9 Maret 2017 (Gelombang 2), dan 13 April 2018 (Gelombang 3)', '11012018204231'),
(13, 'BukaBeasiswa 2018', 'Tunjangan Biaya Pendidikan + Tunjangan Hidup', '11012018204736');

-- --------------------------------------------------------

--
-- Table structure for table `kompetisi`
--

CREATE TABLE `kompetisi` (
  `id` int(100) NOT NULL,
  `judul` text NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kompetisi`
--

INSERT INTO `kompetisi` (`id`, `judul`, `deskripsi`, `foto`) VALUES
(46, 'MaGe 2018', 'Tanggal : 24 s.d 25 Februari 2018 (Puncak Acara) || Multimedia and Game', '11012018202506'),
(47, 'Kompetisi KPK', 'Lomba Cipta Media Pembelajaran Anti Korupsi', '11012018202643'),
(50, 'IYCF 2018', ' Deadline: 05 Februari 2018 ||Indonesia Youth Colaboration Forum 2018', '11012018203224'),
(51, 'Lomba Desain Poster', 'DEADLINE: 1 Maret 2018INFO SAYEMBARA DESAIN - Info Lomba 2018 | Lomba Desain Poster berikut ini diselenggarakan oleh HIMATEMIA FT UNILA, Lampung, pada bulan Maret 2018.', '11012018203404');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(100) NOT NULL,
  `id_pemesan` int(100) NOT NULL,
  `banyakoin` int(100) NOT NULL,
  `total_harga` int(100) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `id_pemesan`, `banyakoin`, `total_harga`, `file`, `status`) VALUES
(1, 15, 0, 60000, NULL, NULL),
(2, 15, 20, 60000, NULL, NULL),
(3, 15, 20, 60000, NULL, NULL),
(4, 15, 90, 270000, NULL, NULL),
(5, 15, 40, 120000, NULL, NULL),
(6, 16, 1, 3000, NULL, NULL),
(7, 16, 1, 3000, NULL, NULL),
(8, 19, 1, 3000, NULL, NULL),
(9, 19, 111, 333000, NULL, NULL),
(10, 16, 1, 3000, NULL, NULL),
(11, 16, 1, 3000, NULL, NULL),
(12, 16, 1, 3000, NULL, NULL),
(13, 16, 10, 30000, NULL, NULL),
(14, 16, 10, 30000, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE `tbl_uploads` (
  `id` int(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`id`, `file`, `type`, `size`) VALUES
(1, 'Mei', '', 0),
(2, '93541-20170311_092727.jpg', 'image/jpeg', 1931),
(3, '5138-20170311_092727.jpg', 'image/jpeg', 1931),
(4, '60573-20170311_092727.jpg', 'image/jpeg', 1931),
(5, '8354-20170311_092727.jpg', 'image/jpeg', 1931),
(6, '2028-1479881578529.jpg', 'image/jpeg', 65),
(7, '81232-bagi5.png', 'image/png', 73),
(8, '79825-bagi5.png', 'image/png', 73),
(9, '93552-komp_4.jpg', 'image/jpeg', 172),
(10, '22713-capture.jpg', 'image/jpeg', 10),
(11, '72593-capture.jpg', 'image/jpeg', 10),
(12, '42573-download-(1).png', 'image/png', 4),
(13, '91461-download-(1).png', 'image/png', 4),
(14, '61746-201801223-excess-2018-lomba-desain-poster-universitas-lampung---infosayembara-s107.jpg', 'image/jpeg', 8);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `poin` int(2) NOT NULL,
  `nim` varchar(100) DEFAULT NULL,
  `universitas` varchar(100) DEFAULT NULL,
  `program_studi` varchar(100) DEFAULT NULL,
  `gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `poin`, `nim`, `universitas`, `program_studi`, `gender`) VALUES
(9, 'mei', 'mei@mail.com', '072a740d449903272a42b3e423dae733', 10, '', '', '', ''),
(15, 'meiket', 'meiket@gmail.com', '88e5cc4742524d6c357bad341f5901b6', 82, '', '', '', ''),
(16, 'anggi', 'anggi@mail.com', 'e0bf5f93b93a528bd5cdb05f621d7202', 129, '', '', '', ''),
(18, 'meiketaren', 'meiketaren@gmail.com', 'cd59d25e69dd42353a77c5717fbe8ba6', 7, NULL, NULL, NULL, ''),
(19, 'admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 228, NULL, NULL, NULL, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beasiswa`
--
ALTER TABLE `beasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kompetisi`
--
ALTER TABLE `kompetisi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`),
  ADD KEY `fk_1` (`id_pemesan`);

--
-- Indexes for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beasiswa`
--
ALTER TABLE `beasiswa`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `kompetisi`
--
ALTER TABLE `kompetisi`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `pesan`
--
ALTER TABLE `pesan`
  ADD CONSTRAINT `fk_1` FOREIGN KEY (`id_pemesan`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
