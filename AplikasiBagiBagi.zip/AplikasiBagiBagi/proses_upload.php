<br><br><br><br><br><br><br><br><br><br><br><br><br>


<?php



session_start();


include_once 'dbconnect.php';
// include_once 'head.php';

$mei =$_SESSION['usr_id'];
$id_pesan = $_GET['id'];




$temp = "SELECT banyakoin from pesan where id_pesan= $id_pesan";
$sql = mysqli_query($con,$temp);
$data = mysqli_fetch_array($sql);
$poin = $data['banyakoin'];
// var_dump($poin);die();


$query = "SELECT poin from users where id = $mei";

$sql2 = mysqli_query($con,$query);
$data2 = mysqli_fetch_array($sql2);

$poinsaya = $data2['poin'];
// var_dump($poinsaya);die();




$totalpoin = $poinsaya + $poin;

$poinbaru = "UPDATE users set poin= ".$totalpoin."  where id ='".$mei."'";

$sql3 = mysqli_query($con, $poinbaru);

// $data3 = mysqli_fetch_array($sql3);

// $poinsekarang = $data3['poin'];

// var_dump($poinsekarang);die();

if($poinbaru){
// header('location : index.php');

header("location: index.php");
}


?>