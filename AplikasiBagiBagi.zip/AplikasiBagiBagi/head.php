				<link href="css/bootstrap.css" rel="stylesheet">
				<link href="css/bootstrap.min.css" rel="stylesheet">
			    <link href="css/font-awesome.min.css" rel="stylesheet">

			     <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
   				 <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
				<link rel="stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
				<link href="css/nivo-lightbox.css" rel="stylesheet" />
				<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
				<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
   				 <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
				<link href="css/animate.css" rel="stylesheet" />
    			<link href="css/style.css" rel="stylesheet">

    			<!-- boxed bg -->
	<link id="bodybg" href="bodybg/bg1.css" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="color/default.css" rel="stylesheet">

				<script type="text/javascript" src="jquery-1.9.1.min.js" charset="utf-8"></script>
				<script src="js/jquery-3.1.1.min.js"></script>
				<script src="js/bootstrap.min.js"></script>
				<script src="js/twd-menu.js"></script>

				<!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
    <script src="js/custom.js"></script>
    

				<!-- for slider-->
				<script type="text/javascript" src="js/jquery1.min.js"></script>
				<link rel="stylesheet" href="css/fwslider.css" media="all">
			    <script src="js/jquery-ui.min.js"></script>
				<!-- <script src="js/fwslider.js"></script> -->
				<link href="css/haha.css" rel="stylesheet">
				
				<link rel="stylesheet" href="css/etalage.css">
				<script src="js/jquery.etalage.min.js"></script>
				<script type="text/javascript" src="js/jquery.flexisel.js"></script>				
				<link href="css/form.css" rel="stylesheet" type="text/css" media="all" />
				<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
				<script src="js/slides.min.jquery.js"></script>
				<script src="js/new.js"></script>
				
				<link href="css/newstyle.css" rel="stylesheet">

				<script src="js/jquery.dataTables.js"></script>
			    <script src="js/dataTables.bootstrap.js"></script>
			    <link href="css/dataTables.bootstrap.css" rel="stylesheet" />
			        <script>
			            $(document).ready(function () {
			                $('#dataTables-example').dataTable();
			            });
			    </script>
			 
			    <link href="css/owl.carousel.css" rel="stylesheet" media="screen">
			    <link href="css/owl.theme.css" rel="stylesheet" media="screen">
			    

			    <script type="text/javascript" src="js/owl.carousel.js"></script>
			    <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
			    <script type="text/javascript" src="js/main.js"></script>

			    
			</head>

			<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
			<div id="wrapper">
		<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-md-6">
					<big> <b>  
					<?php
					echo " <span>" . date('l, Y-m-d') . "<br>";
					?>
					</b> </big>
					</div>
					<div class="col-sm-6 col-md-6">
					<p class="bold text-right">Selamat Berbagi!</p>
					</div>
				</div>
			</div>
		</div>

        <div class="container navigation">
		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.html">
                    <img src="img/bagi7.png" alt="" width="300" height="55" />
                </a>
            </div>

           <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			  <ul class="nav navbar-nav">
			  <?php if (isset($_SESSION['usr_id'])) { ?>
				<li><p class="navbar-text">Hai, Selamat Datang <?php echo $_SESSION['usr_name']; ?></p></li>
				<li ><a href="index.php">Home</a></li>
				<li><a href="kompetisi.php">Kompetisi</a></li>
				<li><a href="beasiswa.php">Beasiswa</a></li>
				<li class="active"><a href="akun.php">Data Diri</a></li>
				<li><a href="logout.php">Logout</a></li>
				<?php } else { ?>
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="">Tentang Kami</a></li>
				<li><a href="kompetisi.php">Kompetisi</a></li>
				<li><a href="beasiswa.php">Beasiswa</a></li>
				<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="badge custom-badge red pull-right"></span>MASUK WEBSITE <b class="caret"></b></a>
				 <ul class="dropdown-menu">
					<li><a href="login.php"> Sudah Punya Akun </a></li>
					<li><a href="register.php"> Belum Punya Akun</a></li>
					<?php } ?>
				  </ul>
				</li>
			  </ul>
            </div>
            <!-- /.navbar-collapse -->
       
        <!-- /.container -->
    
				</header>
