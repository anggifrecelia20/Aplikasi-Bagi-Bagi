<?php
//connect to mysql database
$con = mysqli_connect("localhost", "root", "", "mecio") or die("Error " . mysqli_error($con));
?>


<?php
	function get_title($_title){
		return ('<title>' .$_title. '</title>');
	}

	function open_page($_title){
		echo ('<html><head>' .get_title($_title).
			'</head></head><body>');
	}

	function close_page(){
		echo('</body></html>');
	}

	function redirect($_location){
		header('Location: ' .$_location);
	}

	function profile($id){
		$query = "SELECT * FROM users WHERE id='$id'";
		return execQ($query);
	}

	function profilUpdateProcess($name, $nim, $universitas, $program_studi, $email, $gender){
		$query = "UPDATE users SET name='$name', nim='$nim', universitas='$universitas', program_studi='$program_studi', gender='$gender' WHERE id='$id'";
		return execQ($query);
	}

	function upd_password($new_pass, $id){
		$query = "UPDATE users SET password='$new_pass' WHERE id='$id'";
		return execQ($query);
	}

	function upd_photo($target_file, $id){
		$query = "UPDATE users SET gambar='$target_file' WHERE id='$id'";
		return execQ($query);
	}
  ?>