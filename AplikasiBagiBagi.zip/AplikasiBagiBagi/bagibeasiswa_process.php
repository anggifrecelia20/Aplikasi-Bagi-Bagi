<?php
// Load file koneksi.php
include "dbconnect.php";
session_start();

$usr_id = $_SESSION['usr_id'];
// echo "".$usr_id;
// die();

// Ambil Data yang Dikirim dari Form
$judul = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$date = $_FILES['foto']['name'];
$tmp = $_FILES['foto']['tmp_name'];
	
// Rename nama fotonya dengan menambahkan tanggal dan jam upload
$fotobaru = date('dmYHis').$foto;

// Set path folder tempat menyimpan fotonya
$path = "img/".$fotobaru;

// Proses upload
//echo "judul:".$judul;

//echo "judul:".$deskripsi;

// echo "judul:".$foto;

if(move_uploaded_file($tmp, $path)){ // Cek apakah gambar berhasil diupload atau tidak
	// Proses simpan ke Database

// var_dump(move_uploaded_file($tmp, $path));die();


// "UPDATE users SET poin=poin-3  WHERE id =".$_SESSION['usr_id'];

$mei = "INSERT INTO beasiswa(judul, deskripsi, foto) VALUES('" . $judul . "', '" . $deskripsi . "', '" . $fotobaru . "')";
// var_dump($mei);die();


	// $query = mysqli_query($con, $mei);





	// $sql = mysqli_query($con, $query); // Eksekusi/ Jalankan query dari variabel $query
    $result_set = $con->query($mei);

	// var_dump($result_set);die();

// var_dump($query);die();

	if($result_set){ // Cek jika proses simpan ke database sukses atau tidak
		// Jika Sukses, Lakukan :

				$sql = "UPDATE users SET poin=poin+3  WHERE id =".$_SESSION['usr_id'];
				
				$result_sets = $con->query($sql);



		header("location: beasiswa.php"); // Redirect ke hash_algos()aman index.php
	}else{
		// Jika Gagal, Lakukan :
		echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
		echo "<br><a href='bagi_beasiswa.php'>Kembali Ke Form</a>";
	}
}else{
	// Jika gambar gagal diupload, Lakukan :
	echo "Maaf, Gambar gagal untuk diupload.";
	echo "<br><a href='bagi_beasiswa.php'>Kembali Ke Form</a>";
}
?>











